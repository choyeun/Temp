const card = styled(motion.div)`
  background-color: white;
  height: 70px;
  width: 70px;
  place-self: center;
  border-radius: 35px;
  box-shadow: 0px 0px 15px 3px rgba(0, 0, 0, 0.2);
`;

function App() {
  return (
    <Components>
        <card />
        <card />
    </Components>
  );
}


const boxVariants = {
    start: {
      opacity: 0,
      scale: 0.5,
    },
    end: {
      opacity: 1,
      scale: 1,
      transition: {
        type: "spring",
        duration: 0.5,
        bounce: 0.5,
        delayChildren: 0.3,
        staggerChildren: 0.2,
      },
    },
  };